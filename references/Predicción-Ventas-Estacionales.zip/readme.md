# install venv in jupyter
```
ipython kernel install --user --name=.venv
jupyter kernelspec list
jupyter kernelspec remove <kernel-name>
jupyter kernelspec uninstall <kernel-name>
```
