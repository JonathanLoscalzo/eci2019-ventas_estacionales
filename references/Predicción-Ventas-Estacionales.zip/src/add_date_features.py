import numpy as np

def add_date_features(df, col_name="fecha"):
    """
    Esta función transforma una columna que se recibe como parámetro, 
    en varias columnas derivadas. 
    """
    df['date'] = df[col_name]
    df['dayofweek'] = df['date'].dt.dayofweek
    df['year'] = df['date'].dt.year
    df['month'] = df['date'].dt.month
    df['dayofyear'] = df['date'].dt.dayofyear
    df['dayofmonth'] = df['date'].dt.day
    df['weekofyear'] = df['date'].dt.weekofyear
    df['is_weekend'] = np.where(df['date'].dt.dayofweek.isin([5,6]), 1, 0)
    df = df.drop([col_name,'date'], axis=1, errors='ignore')
    
    return df
