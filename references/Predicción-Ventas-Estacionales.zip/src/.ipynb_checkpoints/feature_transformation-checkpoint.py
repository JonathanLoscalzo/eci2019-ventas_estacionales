import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer

def impute_values(df):
    """
    está funcion se encaga de imputar los valores del dataframe que recibe (todas las columnas por igual)
    """
    #estrategia de imputación, con valores medios.
    imp = SimpleImputer(strategy='mean')

    #imputamos
    df_impute = pd.DataFrame(imp.fit_transform(df))
    df_impute.columns = df.columns
    return df_impute

def assign_tipo_pos(df_pos, df_ventas_pos_freq):
    df_pos.loc[lambda df: 
               (df.ventas >= df_ventas_pos_freq.loc["POCAS","ini"]) 
               & (df.ventas <= df_ventas_pos_freq.loc["POCAS","fin"]), "tipo_pos_ventas"] = "POCAS"
    
    df_pos.loc[lambda df: 
               (df.ventas >= df_ventas_pos_freq.loc["MEDIO","ini"]) 
               & (df.ventas <= df_ventas_pos_freq.loc["MEDIO","fin"]), "tipo_pos_ventas"] = "MEDIO"
    
    df_pos.loc[lambda df: 
               (df.ventas >= df_ventas_pos_freq.loc["MUCHAS","ini"]) 
               & (df.ventas <= df_ventas_pos_freq.loc["MUCHAS","fin"]), "tipo_pos_ventas"] = "MUCHAS"
    
    df_pos.loc[lambda df: 
               (df.ventas >= df_ventas_pos_freq.loc["SIN VENTAS","ini"]) 
               & (df.ventas <= df_ventas_pos_freq.loc["SIN VENTAS","fin"]), "tipo_pos_ventas"] = "SIN VENTAS"
    
