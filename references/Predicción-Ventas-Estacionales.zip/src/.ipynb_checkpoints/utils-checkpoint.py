import pandas as pd

def get_date_for_timestamp_file():
    def zfill_elements(arr):
        return list(map(lambda a: a.zfill(2),map(str, arr)))

    dt = pd.to_datetime('now').tz_localize('UTC').tz_convert("America/Argentina/Buenos_Aires")
    dt = zfill_elements([dt.year,dt.month,dt.day, dt.hour, dt.minute,dt.second])
    dt = "{}-{}-{}_{}:{}:{}".format(*dt)
    return dt