cols_edad = [
    "pct_0a5",
    "pct_5a9",
    "pct_10a14",
    "pct_15a19",
    "pct_20a24",
    "pct_25a29",
    "pct_30a34",
    "pct_35a39",
    "pct_40a44",
    "pct_45a49",
    "pct_50a54",
    "pct_55a59",
    "pct_60a64",
    "pct_65a69",
    "pct_70a74",
    "pct_75a79",
    "pct_80a84",
    "pct_85ainf",
]

cols_edad_nuevas = ['pct_0a14','pct_15a39','pct_40a59','pct_60aInf']

cols_estudios = [
    "pct_secundario",
    "pct_bachelors",
    "pct_doctorados",
    "pct_master",
]

cols_estudios_nuevas = ["pct_secundario","pct_universiatarios"]

cols_transporte = [
    "pct_bicicleta",
    "pct_omnibus",
    "pct_subtes",
    "pct_taxi",
    "pct_caminata",
]

cols_ingresos = [
    "ingreso_mediana",
    "ingreso_promedio",
    "mediana_valor_hogar"
]

cols_otros = [
    "competidores",
    "densidad_poblacional",
]