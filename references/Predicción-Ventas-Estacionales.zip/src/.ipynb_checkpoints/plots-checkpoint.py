import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt

def plot_importance_reg(reg, columns, title):
    # https://scikit-learn.org/stable/auto_examples/ensemble/plot_gradient_boosting_regression.html#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-regression-py
    
    top_n = 10
    feat_imp = pd.DataFrame({'importance':reg.feature_importances_})    
    feat_imp['feature']=columns
    feat_imp.sort_values(by='importance', ascending=False, inplace=True)
    feat_imp = feat_imp.iloc[:top_n]
    
    feat_imp.sort_values(by='importance', inplace=True)
    feat_imp = feat_imp.set_index('feature', drop=True)
    feat_imp.plot.barh(title=title, figsize=(12,6))
    plt.xlabel('Feature Importance Score')
    plt.show()

